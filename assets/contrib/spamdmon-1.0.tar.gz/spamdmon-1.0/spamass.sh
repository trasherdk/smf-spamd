#!/bin/sh

/usr/bin/spamd --daemonize
