#!/bin/sh

/usr/local/sbin/spamdmon && (killall spamd; sleep 5; killall -9 spamd; sleep 1; /usr/local/sbin/spamass.sh)

